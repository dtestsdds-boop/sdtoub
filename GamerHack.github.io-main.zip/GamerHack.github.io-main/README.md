# PS4 - PS5 Exploit Host
PS4 Firmwares: `5.05` `6.72` `7.02` `7.5X` `9.00`

PS5 Firmwares: `1.XX` `5.XX`

## Steps:

- In the console browser go to: https://gamerhack.github.io/
- Select the firmware of your console.
- Immediately all content will be installed in the offline cache, once finished exit the browser and turn off the Internet.
- Then go back to Access Browser and Enjoy.

Download link for the PS5 host shortcut .pkg file:
https://www.mediafire.com/file/dh3tzdvfmcznmrs/NPXS40138_%2528UMTX2%2529.pkg/file